# Dictionnaire des LLMs distant via Hugging Face
MODELS_ENLIGNE = {
    1: {
        "nom": "DeepSeek V3 Chat",
        "api_url": "deepseek-ai/DeepSeek-V3-0324",
        "model_id": "deepseek-ai/DeepSeek-V3-0324" 
    }
}
